<!DOCTYPE html>

<html>

<head>

    <title>
    	IPI formation
    </title>

    <meta charset="UTF-8">


</head>
<body>

<h1>Formations ipi</h1>

<table><th>
	<td><a href="index.php">Accueil</a></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td><a href="presentation.php">Présentation ipi</a></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td><a href="formations.php">Rechercher une formation</a></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td><a href="contact.php">Contact</a></td>
</th></table>
<br/>
<strong>186 Route de Grenade 31703 BLAGNAC<br/></strong>
Accueil : 05 31 08 70 00
<br /><ul>
<li>Responsable Pédagogique<br/>
05 31 08 70 71<br/>
Christelle BOUDET cboudet@groupe-igs.fr<br/></li>

<li>Relations Entreprises, Alternance<br/>
05 31 08 70 83<br/>
Romain BONNET rbonnet@groupe-igs.fr<br/></li>
<br/>
<li>Service Communication et Admission<br/>
05 31 08 70 74<br/>
Sabrina THIBAUT sthibaut@groupe-igs.fr</li>
</ul>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.2079692484676!2d1.3846943154974494!3d43.643841279121645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12aea53f4e7cfb37%3A0x4fd605c00c060ba2!2sIPI+Toulouse+-+Ecole+d&#39;informatique!5e0!3m2!1sen!2sfr!4v1532776027696" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</body>
</html>
