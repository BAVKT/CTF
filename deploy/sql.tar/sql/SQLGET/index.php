<!DOCTYPE html>

<html>

<head>

    <title>
    	IPI formation
    </title>

    <meta charset="UTF-8">


</head>
<body>

<h1>Formations ipi</h1>

<table><th>
	<td><a href="index.php">Accueil</a></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td><a href="presentation.php">Présentation ipi</a></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td><a href="formations.php">Rechercher une formation</a></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td><a href="contact.php">Contact</a></td>
</th></table>

<h2>Informatique et Numérique<br />
Connectez-vous au monde de l'entreprise</h2>
<br />
<p>L’IPI, école d’informatique du Groupe IGS, accompagne chaque année plus de 500 personnes de tous âges dans leur développement professionnel à travers des titres reconnus et accessibles par la formation initiale, l’alternance, l’apprentissage, la VAE ou la formation continue.</p>

</body>
</html>
